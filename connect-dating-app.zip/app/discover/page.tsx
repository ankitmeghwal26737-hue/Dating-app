import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/prisma";
import { redirect } from "next/navigation";
import { LikeButton } from "./like-button";

export default async function Discover() {
  const me = await getCurrentUser();
  if (!me) redirect("/login");
  if (!me.profile) redirect("/profile/setup");

  const blocked = await db.block.findMany({ where: { OR: [{ blockerId: me.id }, { blockedId: me.id }] } });
  const blockedIds = blocked.flatMap(b => [b.blockerId, b.blockedId]);

  const users = await db.user.findMany({
    where: { id: { not: me.id, notIn: blockedIds }, suspended: false, profile: { isNot: null } },
    include: { profile: true, photos: { take: 1 } },
    take: 30,
    orderBy: { createdAt: "desc" }
  });

  return <main className="max-w-3xl mx-auto p-6">
    <header className="flex justify-between items-center mb-6"><h1 className="text-3xl font-black">Discover</h1><a href="/matches">Matches</a></header>
    <div className="grid gap-5 sm:grid-cols-2">
      {users.map(u => <article key={u.id} className="card overflow-hidden">
        {u.photos[0] ? <img src={u.photos[0].url} alt="" className="w-full aspect-square object-cover" /> : <div className="aspect-square bg-zinc-100 flex items-center justify-center">No photo</div>}
        <div className="p-5">
          <h2 className="text-xl font-bold">{u.profile?.name}</h2>
          <p className="text-zinc-500">{u.profile?.city}</p>
          <p className="mt-3">{u.profile?.bio}</p>
          <p className="text-sm mt-3">{u.profile?.interests.join(" • ")}</p>
          <LikeButton targetId={u.id} />
        </div>
      </article>)}
    </div>
  </main>;
}