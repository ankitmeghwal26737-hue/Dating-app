 "use client";
import { useState } from "react";
export function LikeButton({ targetId }: { targetId: string }) {
  const [done, setDone] = useState(false);
  async function like() {
    const r = await fetch("/api/like", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ targetId }) });
    if (r.ok) setDone(true);
  }
  return <button disabled={done} onClick={like} className="mt-5 w-full rounded-xl bg-black text-white p-3">{done ? "Liked" : "Like"}</button>;
}