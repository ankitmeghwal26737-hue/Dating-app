 "use server";

import { db } from "@/lib/prisma";
import { createSession } from "@/lib/auth";
import bcrypt from "bcryptjs";
import { redirect } from "next/navigation";
import { z } from "zod";

function is18(d: Date) {
  const now = new Date();
  const cutoff = new Date(now.getFullYear() - 18, now.getMonth(), now.getDate());
  return d <= cutoff;
}

export async function signup(form: FormData) {
  const data = {
    email: String(form.get("email") || "").trim().toLowerCase(),
    password: String(form.get("password") || ""),
    dob: String(form.get("dateOfBirth") || ""),
    adult: form.get("adultConfirm") === "on"
  };
  const parsed = z.object({
    email: z.email(),
    password: z.string().min(8).max(128),
    dob: z.string().min(1)
  }).safeParse(data);
  if (!parsed.success || !data.adult) throw new Error("Invalid signup data.");
  const dob = new Date(data.dob);
  if (Number.isNaN(dob.getTime()) || !is18(dob)) throw new Error("Connect is available only to users aged 18+.");

  const exists = await db.user.findUnique({ where: { email: data.email } });
  if (exists) throw new Error("An account already exists.");
  const passwordHash = await bcrypt.hash(data.password, 12);
  const user = await db.user.create({ data: { email: data.email, passwordHash, dateOfBirth: dob } });
  await createSession(user.id);
  redirect("/profile/setup");
}

export async function login(form: FormData) {
  const email = String(form.get("email") || "").trim().toLowerCase();
  const password = String(form.get("password") || "");
  const user = await db.user.findUnique({ where: { email } });
  if (!user || !(await bcrypt.compare(password, user.passwordHash)) || user.suspended) {
    throw new Error("Invalid credentials or suspended account.");
  }
  await createSession(user.id);
  redirect("/discover");
}