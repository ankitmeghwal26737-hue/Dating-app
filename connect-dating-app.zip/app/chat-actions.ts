 "use server";
import { db } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { redirect } from "next/navigation";
export async function sendMessage(form: FormData) {
  const me=await getCurrentUser(); if(!me || me.suspended) throw new Error("Unauthorized");
  const matchId=String(form.get("matchId")||"");
  const body=String(form.get("body")||"").trim();
  if(!body || body.length>1000) throw new Error("Invalid message");
  const match=await db.match.findUnique({where:{id:matchId}});
  if(!match || (match.userAId!==me.id && match.userBId!==me.id)) throw new Error("Forbidden");
  await db.message.create({data:{matchId,senderId:me.id,body}});
  redirect(`/chat/${matchId}`);
}