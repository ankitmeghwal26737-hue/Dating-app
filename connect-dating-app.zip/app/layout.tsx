import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Connect",
  description: "18+ social matching application"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}