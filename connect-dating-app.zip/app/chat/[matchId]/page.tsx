import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/prisma";
import { redirect } from "next/navigation";
import { sendMessage } from "../../chat-actions";
export default async function Chat({params}:{params:Promise<{matchId:string}>}) {
  const me=await getCurrentUser(); if(!me) redirect("/login");
  const {matchId}=await params;
  const match=await db.match.findUnique({where:{id:matchId},include:{userA:{include:{profile:true}},userB:{include:{profile:true}},messages:{include:{sender:true},orderBy:{createdAt:"asc"},take:100}}});
  if(!match || (match.userAId!==me.id && match.userBId!==me.id)) redirect("/matches");
  return <main className="max-w-2xl mx-auto p-6"><h1 className="text-2xl font-bold mb-5">Chat</h1>
    <div className="card p-4 min-h-80 space-y-3">{match.messages.map(m=><div key={m.id} className={m.senderId===me.id?"text-right":""}><span className="inline-block bg-zinc-100 rounded-xl px-3 py-2">{m.body}</span></div>)}</div>
    <form action={sendMessage} className="flex gap-2 mt-3"><input type="hidden" name="matchId" value={matchId}/><input name="body" required maxLength={1000} className="flex-1 border rounded-xl p-3" placeholder="Write a message"/><button className="bg-black text-white rounded-xl px-5">Send</button></form>
  </main>;
}