 "use server";
import { db } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { redirect } from "next/navigation";
import { z } from "zod";

export async function setupProfile(form: FormData) {
  const user = await getCurrentUser();
  if (!user || user.suspended) throw new Error("Unauthorized");
  const data = z.object({
    name: z.string().min(1).max(50),
    city: z.string().max(80),
    bio: z.string().max(500),
    gender: z.enum(["MALE","FEMALE","OTHER"]),
    preference: z.string().max(80),
    interests: z.string().max(300)
  }).parse({
    name: String(form.get("name") || ""),
    city: String(form.get("city") || ""),
    bio: String(form.get("bio") || ""),
    gender: String(form.get("gender") || ""),
    preference: String(form.get("preference") || ""),
    interests: String(form.get("interests") || "")
  });
  await db.profile.upsert({
    where: { userId: user.id },
    update: { ...data, interests: data.interests.split(",").map(x => x.trim()).filter(Boolean) },
    create: { userId: user.id, ...data, interests: data.interests.split(",").map(x => x.trim()).filter(Boolean) }
  });
  redirect("/discover");
}