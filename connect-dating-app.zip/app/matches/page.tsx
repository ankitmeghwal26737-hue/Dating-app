import { getCurrentUser } from "@/lib/auth";
import { db } from "@/lib/prisma";
import { redirect } from "next/navigation";
export default async function Matches() {
  const me = await getCurrentUser();
  if (!me) redirect("/login");
  const matches = await db.match.findMany({
    where: { OR: [{userAId:me.id},{userBId:me.id}] },
    include: { userA:{include:{profile:true}}, userB:{include:{profile:true}} },
    orderBy:{createdAt:"desc"}
  });
  return <main className="max-w-2xl mx-auto p-6"><h1 className="text-3xl font-bold mb-6">Matches</h1>
    <div className="space-y-3">{matches.map(m => {
      const other = m.userAId === me.id ? m.userB : m.userA;
      return <a key={m.id} href={`/chat/${m.id}`} className="card p-4 flex justify-between"><span className="font-semibold">{other.profile?.name || "User"}</span><span>Open chat →</span></a>
    })}</div>
  </main>;
}