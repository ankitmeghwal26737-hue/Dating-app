import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center p-6">
      <section className="max-w-xl text-center">
        <div className="text-5xl font-black mb-4">Connect</div>
        <p className="text-zinc-600 text-lg mb-8">
          A privacy-focused social matching app for adults 18+.
        </p>
        <div className="flex gap-3 justify-center">
          <Link className="rounded-xl bg-black text-white px-6 py-3" href="/signup">Create account</Link>
          <Link className="rounded-xl border px-6 py-3" href="/login">Login</Link>
        </div>
        <p className="text-xs text-zinc-500 mt-8">18+ only. Respect others. Block or report unsafe behavior.</p>
      </section>
    </main>
  );
}