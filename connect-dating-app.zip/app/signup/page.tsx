import { signup } from "../actions";
export default function Signup() {
  return <main className="max-w-md mx-auto p-6">
    <h1 className="text-3xl font-bold mb-6">Create account</h1>
    <form action={signup} className="space-y-4 card p-6">
      <input name="email" type="email" required placeholder="Email" className="w-full border rounded-xl p-3" />
      <input name="password" type="password" required minLength={8} placeholder="Password (8+ characters)" className="w-full border rounded-xl p-3" />
      <label className="block text-sm">Date of birth
        <input name="dateOfBirth" type="date" required className="w-full border rounded-xl p-3 mt-1" />
      </label>
      <label className="flex gap-2 text-sm"><input name="adultConfirm" type="checkbox" required /> I confirm I am 18 or older.</label>
      <button className="w-full rounded-xl bg-black text-white p-3">Create account</button>
    </form>
  </main>;
}