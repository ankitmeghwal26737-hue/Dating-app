import { setupProfile } from "../../profile-actions";
export default function Setup() {
  return <main className="max-w-lg mx-auto p-6">
    <h1 className="text-3xl font-bold mb-6">Set up your profile</h1>
    <form action={setupProfile} className="card p-6 space-y-4">
      <input name="name" required maxLength={50} placeholder="Name" className="w-full border rounded-xl p-3" />
      <input name="city" maxLength={80} placeholder="City" className="w-full border rounded-xl p-3" />
      <select name="gender" required className="w-full border rounded-xl p-3">
        <option value="">Gender</option><option value="MALE">Male</option><option value="FEMALE">Female</option><option value="OTHER">Other</option>
      </select>
      <input name="preference" maxLength={80} placeholder="Who would you like to meet?" className="w-full border rounded-xl p-3" />
      <input name="interests" maxLength={300} placeholder="Interests (comma separated)" className="w-full border rounded-xl p-3" />
      <textarea name="bio" maxLength={500} placeholder="Short bio" className="w-full border rounded-xl p-3 min-h-28" />
      <button className="w-full rounded-xl bg-black text-white p-3">Save profile</button>
    </form>
  </main>;
}