import { login } from "../actions";
export default function Login() {
  return <main className="max-w-md mx-auto p-6">
    <h1 className="text-3xl font-bold mb-6">Login</h1>
    <form action={login} className="space-y-4 card p-6">
      <input name="email" type="email" required placeholder="Email" className="w-full border rounded-xl p-3" />
      <input name="password" type="password" required placeholder="Password" className="w-full border rounded-xl p-3" />
      <button className="w-full rounded-xl bg-black text-white p-3">Login</button>
    </form>
  </main>;
}