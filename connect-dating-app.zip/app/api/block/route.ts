import { NextResponse } from "next/server";
import { db } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
export async function POST(req:Request){
  const me=await getCurrentUser(); if(!me) return NextResponse.json({error:"Unauthorized"},{status:401});
  const {userId}=await req.json();
  if(typeof userId!=="string" || userId===me.id) return NextResponse.json({error:"Invalid"},{status:400});
  await db.block.upsert({where:{blockerId_blockedId:{blockerId:me.id,blockedId:userId}},update:{},create:{blockerId:me.id,blockedId:userId}});
  return NextResponse.json({ok:true});
}