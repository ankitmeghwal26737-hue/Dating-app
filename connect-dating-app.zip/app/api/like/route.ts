import { NextResponse } from "next/server";
import { db } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me || me.suspended) return NextResponse.json({error:"Unauthorized"}, {status:401});
  const { targetId } = await req.json();
  if (typeof targetId !== "string" || targetId === me.id) return NextResponse.json({error:"Invalid"}, {status:400});

  const target = await db.user.findUnique({ where: { id: targetId } });
  if (!target || target.suspended) return NextResponse.json({error:"Not found"}, {status:404});

  const blocked = await db.block.findFirst({ where: { OR: [
    { blockerId: me.id, blockedId: targetId }, { blockerId: targetId, blockedId: me.id }
  ]}});
  if (blocked) return NextResponse.json({error:"Blocked"}, {status:403});

  await db.like.upsert({
    where: { fromUserId_toUserId: { fromUserId: me.id, toUserId: targetId } },
    update: {},
    create: { fromUserId: me.id, toUserId: targetId }
  });

  const reverse = await db.like.findUnique({ where: { fromUserId_toUserId: { fromUserId: targetId, toUserId: me.id } }});
  if (reverse) {
    const [a,b] = [me.id, targetId].sort();
    await db.match.upsert({ where: { userAId_userBId: { userAId: a, userBId: b } }, update: {}, create: { userAId:a, userBId:b }});
    return NextResponse.json({matched:true});
  }
  return NextResponse.json({matched:false});
}