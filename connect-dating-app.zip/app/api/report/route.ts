import { NextResponse } from "next/server";
import { db } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
export async function POST(req:Request){
  const me=await getCurrentUser(); if(!me) return NextResponse.json({error:"Unauthorized"},{status:401});
  const {userId,reason}=await req.json();
  if(typeof userId!=="string" || typeof reason!=="string" || reason.length<3 || reason.length>500) return NextResponse.json({error:"Invalid"},{status:400});
  if(userId===me.id) return NextResponse.json({error:"Invalid"},{status:400});
  await db.report.create({data:{reporterId:me.id,reportedId:userId,reason}});
  return NextResponse.json({ok:true});
}