# Connect — 18+ Matching App

## Requirements
- Node.js 20+
- PostgreSQL

## Setup

```bash
npm install
cp .env.example .env
```

Put your PostgreSQL connection string in `.env`, then:

```bash
npx prisma generate
npx prisma db push
npm run dev
```

Open `http://localhost:3000`.

## Production

```bash
npm run build
npm start
```

## Important
Before public deployment, configure:
- real email verification
- object storage for photos
- HTTPS
- production secrets
- rate limiting at the edge/API layer
- moderation tooling
- privacy policy and terms reviewed for your jurisdiction
- database backups
- logging/monitoring

Do not use the development JWT secret in production.
